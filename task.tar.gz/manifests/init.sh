#!/usr/bin/env bash

sudo systemctl stop te

sudo cp te /bin
sudo chmod 755 /bin/te
sudo cp te.service /etc/systemd/system/

sudo systemctl enable te
sudo systemctl start te
sudo systemctl status te
