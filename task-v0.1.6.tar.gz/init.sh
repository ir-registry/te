#!/usr/bin/env bash

systemctl stop te
systemctl stop task

rm -rf /bin/te /bin/task

cp te task /bin
chmod 755 /bin/te /bin/task

rm -rf /etc/systemd/system/te.service /etc/systemd/system/task.service
cp te.service task.service /etc/systemd/system/

systemctl daemon-reload
systemctl enable te
systemctl start te
systemctl status te

systemctl enable task
systemctl start task
systemctl status task
